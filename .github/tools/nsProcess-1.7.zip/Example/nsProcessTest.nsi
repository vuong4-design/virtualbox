Name "nsProcessTest"
OutFile "nsProcessTest.exe"

!include "nsProcess.nsh"
!include "Sections.nsh"

Var RADIOBUTTON

Page components
Page instfiles


Section "Find process" FindProcess
	${nsProcess::FindProcess} "notepad.exe" $R0
	MessageBox MB_OK "nsProcess::FindProcess$\n$\n\
			Errorlevel: [$R0]"

	${nsProcess::Unload}
SectionEnd


Section /o "Kill process" KillProcess
	loop:
	${nsProcess::FindProcess} "notepad.exe" $R0
	StrCmp $R0 0 0 +2
	MessageBox MB_OKCANCEL|MB_ICONEXCLAMATION 'Close "notepad" before continue' IDOK loop IDCANCEL end

	${nsProcess::KillProcess} "notepad.exe" $R0
	MessageBox MB_OK "nsProcess::KillProcess$\n$\n\
			Errorlevel: [$R0]"

	Exec "notepad.exe"
	Exec "notepad.exe"
	Exec "notepad.exe"
	BringToFront
	MessageBox MB_OK "Press OK and 3 notepad's windows will be closed"

	${nsProcess::KillProcess} "notepad.exe" $R0
	MessageBox MB_OK "nsProcess::KillProcess$\n$\n\
			Errorlevel: [$R0]"

	end:
	${nsProcess::Unload}
SectionEnd

Section /o "Close process" CloseProcess
	${nsProcess::CloseProcess} "notepad.exe" "3000" $R0
	MessageBox MB_OK "nsProcess::KillProcess$\n$\n\
			Errorlevel: [$R0]"

	${nsProcess::Unload}
SectionEnd


Function .onInit
	StrCpy $RADIOBUTTON ${FindProcess}
FunctionEnd

Function .onSelChange
	!insertmacro StartRadioButtons $RADIOBUTTON
	!insertmacro RadioButton ${FindProcess}
	!insertmacro RadioButton ${KillProcess}
	!insertmacro RadioButton ${CloseProcess}
	!insertmacro EndRadioButtons
FunctionEnd
