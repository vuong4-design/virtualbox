/*****************************************************************
 *               nsProcess NSIS plugin v1.7                      *
 *                                                               *
 * 2026 Shengalts Aleksander aka Instructor (Shengalts@mail.ru)  *
 *                                                               *
 * Source function FIND_PROC_BY_NAME based                       *
 *   upon the Ravi Kochhar (kochhar@physiology.wisc.edu) code    *
 * Thanks iceman_k (FindProcDLL plugin) and                      *
 *   DITMan (KillProcDLL plugin) for point me up                 *
 * Thanks brainsucker for CloseProcess code                      *
 *****************************************************************/


#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <Tlhelp32.h>
#include "StrFunc.h"

//Include string functions
#define WideCharLower
#define xstrlenA
#define xstrlenW
#define xstrcpynA
#define xstrcpynW
#define xstrcmpiA
#define xstrcmpiW
#define xatoiW
#define xitoaW
#include "StrFunc.h"

//Defines
#define NSIS_MAX_STRLEN 1024

#define SystemProcessInformation     5
#define STATUS_SUCCESS               0x00000000L
#define STATUS_INFO_LENGTH_MISMATCH  0xC0000004L

typedef struct _SYSTEM_THREAD_INFO {
  FILETIME ftCreationTime;
  DWORD dwUnknown1;
  DWORD dwStartAddress;
  DWORD dwOwningPID;
  DWORD dwThreadID;
  DWORD dwCurrentPriority;
  DWORD dwBasePriority;
  DWORD dwContextSwitches;
  DWORD dwThreadState;
  DWORD dwUnknown2;
  DWORD dwUnknown3;
  DWORD dwUnknown4;
  DWORD dwUnknown5;
  DWORD dwUnknown6;
  DWORD dwUnknown7;
} SYSTEM_THREAD_INFO;

typedef struct _SYSTEM_PROCESS_INFORMATION {
    ULONG NextEntryOffset;
    ULONG NumberOfThreads;
    BYTE Reserved1[48];

    //UNICODE_STRING ImageName;
    USHORT Length;
    USHORT MaximumLength;
    PWSTR  ImageName;

    //KPRIORITY BasePriority;
    UINT_PTR BasePriority;

    HANDLE UniqueProcessId;
    HANDLE InheritedFromUniqueProcessId;
    ULONG HandleCount;
    ULONG SessionId;
    PVOID Reserved3;
    SIZE_T PeakVirtualSize;
    SIZE_T VirtualSize;
    ULONG Reserved4;
    SIZE_T PeakWorkingSetSize;
    SIZE_T WorkingSetSize;
    PVOID Reserved5;
    SIZE_T QuotaPagedPoolUsage;
    PVOID Reserved6;
    SIZE_T QuotaNonPagedPoolUsage;
    SIZE_T PagefileUsage;
    SIZE_T PeakPagefileUsage;
    SIZE_T PrivatePageCount;
    LARGE_INTEGER Reserved7[6];
} SYSTEM_PROCESS_INFORMATION;

//ExDll
typedef struct _stack_t {
  struct _stack_t *next;
  wchar_t text[1];
} stack_t;

typedef struct
{
  int autoclose;
  int all_user_var;
  int exec_error;
  int abort;
  int exec_reboot;
  int reboot_called;
  int XXX_cur_insttype;
  int plugin_api_version;
  int silent;
  int instdir_error;
  int rtl;
  int errlvl;
  int alter_reg_view;
  int status_update;
} exec_flags_t;

typedef struct {
  exec_flags_t *exec_flags;
  int (__stdcall *ExecuteCodeSegment)(int, HWND);
  void (__stdcall *validate_filename)(wchar_t *);
} extra_parameters;

stack_t **g_stacktop;
wchar_t *g_variables;
unsigned int g_stringsize;
extra_parameters *g_pluginParms;
BOOL g_unicode=-1;

//Global variables
char szBuf[NSIS_MAX_STRLEN];
wchar_t wszBuf[NSIS_MAX_STRLEN];

//Funtions prototypes
int FIND_PROC_BY_NAME(unsigned char *pProcessName, BOOL bTerminate, DWORD dwCloseTimeout);
void NiceTerminate(DWORD pid, DWORD dwCloseTimeout, int *lpnSuccess, int *lpnFailed);
BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam);

INT_PTR popintegerWide();
void pushintegerWide(INT_PTR integer);
int popstringAnsi(char *str, int len);
int popstringWide(wchar_t *str, int len);
void pushstringAnsi(const char *str);
void pushstringWide(const wchar_t *str);
void Initialize(int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra);


//Extern functions
void __declspec(dllexport) _FindProcess(HWND hwndParent, int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra)
{
  Initialize(string_size, variables, stacktop, extra);
  {
    unsigned char *pProcessName;
    int nError;

    if (g_unicode)
    {
      popstringWide(wszBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)wszBuf;
    }
    else
    {
      popstringAnsi(szBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)szBuf;
    }
    nError=FIND_PROC_BY_NAME(pProcessName, FALSE, 0);
    pushintegerWide(nError);
  }
}

void __declspec(dllexport) _KillProcess(HWND hwndParent, int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra)
{
  Initialize(string_size, variables, stacktop, extra);
  {
    unsigned char *pProcessName;
    int nError;

    if (g_unicode)
    {
      popstringWide(wszBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)wszBuf;
    }
    else
    {
      popstringAnsi(szBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)szBuf;
    }
    nError=FIND_PROC_BY_NAME(pProcessName, TRUE, 0);
    pushintegerWide(nError);
  }
}

void __declspec(dllexport) _CloseProcess(HWND hwndParent, int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra)
{
  Initialize(string_size, variables, stacktop, extra);
  {
    unsigned char *pProcessName;
    DWORD dwCloseTimeout;
    int nError;

    if (g_unicode)
    {
      popstringWide(wszBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)wszBuf;
    }
    else
    {
      popstringAnsi(szBuf, NSIS_MAX_STRLEN);
      pProcessName=(unsigned char *)szBuf;
    }
    dwCloseTimeout=(DWORD)popintegerWide();
    if (!dwCloseTimeout) dwCloseTimeout=1;
    nError=FIND_PROC_BY_NAME(pProcessName, TRUE, dwCloseTimeout);
    pushintegerWide(nError);
  }
}

void __declspec(dllexport) _Unload(HWND hwndParent, int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra)
{
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
  if (fdwReason == DLL_PROCESS_ATTACH)
  {
  }
  else if (fdwReason == DLL_THREAD_ATTACH)
  {
  }
  else if (fdwReason == DLL_THREAD_DETACH)
  {
  }
  else if (fdwReason == DLL_PROCESS_DETACH)
  {
  }
  return TRUE;
}

int FIND_PROC_BY_NAME(unsigned char *pProcessName, BOOL bTerminate, DWORD dwCloseTimeout)
// Find the process "pProcessName" if it is currently running.
// This works for Win95/98/ME and also WinNT/2000/XP.
// The process name is case-insensitive, i.e. "notepad.exe" and "NOTEPAD.EXE"
// will both work. If bTerminate is TRUE, then process will be terminated.
//
// Return codes are as follows:
//   0   = Success
//   601 = No permission to terminate process
//   602 = Not all processes terminated successfully
//   603 = Process was not currently running
//   604 = Unable to identify system type
//   605 = Unsupported OS
//   606 = Unable to load NTDLL.DLL
//   607 = Unable to get procedure address from NTDLL.DLL
//   608 = NtQuerySystemInformation failed
//   609 = Unable to load KERNEL32.DLL
//   610 = Unable to get procedure address from KERNEL32.DLL
//   611 = CreateToolhelp32Snapshot failed
//
// Change history:
//   created  06/23/2000  - Ravi Kochhar (kochhar@physiology.wisc.edu)
//                            http://www.neurophys.wisc.edu/ravi/software/
//   modified 03/08/2002  - Ravi Kochhar (kochhar@physiology.wisc.edu)
//                          - Borland-C compatible if BORLANDC is defined as
//                            suggested by Bob Christensen
//   modified 03/10/2002  - Ravi Kochhar (kochhar@physiology.wisc.edu)
//                          - Removed memory leaks as suggested by
//                            Jonathan Richard-Brochu (handles to Proc and Snapshot
//                            were not getting closed properly in some cases)
//   modified 14/11/2005  - Shengalts Aleksander aka Instructor (Shengalts@mail.ru):
//                          - Combine functions FIND_PROC_BY_NAME and KILL_PROC_BY_NAME
//                          - Code has been optimized
//                          - Now kill all processes with specified name (not only one)
//                          - Cosmetic improvements
//                          - Removed error 632 (Invalid process name)
//                          - Changed error 602 (Unable to terminate process for some other reason)
//                          - BORLANDC define not needed
//   modified 04/01/2006  - Shengalts Aleksander aka Instructor (Shengalts@mail.ru):
//                          - Removed CRT dependency
//   modified 21/04/2006  - Shengalts Aleksander aka Instructor (Shengalts@mail.ru):
//                          - Removed memory leak as suggested by {_trueparuex^}
//                            (handle to hSnapShot was not getting closed properly in some cases)
//   modified 19/07/2006  - Shengalts Aleksander aka Instructor (Shengalts@mail.ru):
//                          - Code for WinNT/2000/XP has been rewritten
//                          - Changed error codes
//   modified 31/08/2006  - Shengalts Aleksander aka Instructor (Shengalts@mail.ru):
//                          - Removed memory leak as suggested by Daniel Vanesse
{
  OSVERSIONINFO osvi;
  HMODULE hLib;
  ULONG uError;
  BOOL bFound=FALSE;
  int nSuccess=0;
  int nFailed=0;

  // First check what version of Windows we're in
  osvi.dwOSVersionInfoSize=sizeof(OSVERSIONINFO);
  if (!GetVersionEx(&osvi)) return 604;

  if (osvi.dwPlatformId != VER_PLATFORM_WIN32_NT &&
      osvi.dwPlatformId != VER_PLATFORM_WIN32_WINDOWS)
    return 605;

  if (osvi.dwPlatformId == VER_PLATFORM_WIN32_NT)
  {
    // WinNT/2000/XP

    SYSTEM_PROCESS_INFORMATION *spi;
    SYSTEM_PROCESS_INFORMATION *spiCount;
    DWORD dwSize=0x00080000;
    DWORD dwData;
    ULONG (WINAPI *NtQuerySystemInformationPtr)(ULONG, PVOID, LONG, PULONG);

    if (hLib=LoadLibraryA("NTDLL.DLL"))
    {
      NtQuerySystemInformationPtr=(ULONG(WINAPI *)(ULONG, PVOID, LONG, PULONG))GetProcAddress(hLib, "NtQuerySystemInformation");

      if (NtQuerySystemInformationPtr)
      {
        for (;;)
        {
          if (spi=LocalAlloc(LMEM_FIXED, dwSize))
          {
            uError=(*NtQuerySystemInformationPtr)(SystemProcessInformation, spi, dwSize, &dwData);

            if (uError == STATUS_SUCCESS) break;

            LocalFree(spi);

            if (uError != STATUS_INFO_LENGTH_MISMATCH)
            {
              uError=608;
              break;
            }
          }
          else
          {
            uError=608;
            break;
          }
          dwSize*=2;
        }
      }
      else uError=607;

      FreeLibrary(hLib);
    }
    else uError=606;

    if (uError != STATUS_SUCCESS) return uError;

    spiCount=spi;

    for (;;)
    {
      if (spiCount->ImageName)
      {
        if (!xstrcmpiW(spiCount->ImageName, (const wchar_t *)pProcessName))
        {
          // Process found
          bFound=TRUE;

          if (bTerminate == TRUE)
          {
            NiceTerminate((DWORD)(UINT_PTR)spiCount->UniqueProcessId, dwCloseTimeout, &nSuccess, &nFailed);
          }
          else break;
        }
      }
      if (spiCount->NextEntryOffset == 0) break;
      spiCount=(SYSTEM_PROCESS_INFORMATION *)((char *)spiCount + spiCount->NextEntryOffset);
    }
    LocalFree(spi);
  }
  else
  {
    // Win95/98/ME

    PROCESSENTRY32 pe;
    char *pName;
    HANDLE hSnapShot;
    BOOL bResult;
    HANDLE (WINAPI *CreateToolhelp32SnapshotPtr)(DWORD, DWORD);
    BOOL (WINAPI *Process32FirstPtr)(HANDLE, LPPROCESSENTRY32);
    BOOL (WINAPI *Process32NextPtr)(HANDLE, LPPROCESSENTRY32);

    if (hLib=LoadLibraryA("KERNEL32.DLL"))
    {
      CreateToolhelp32SnapshotPtr=(HANDLE(WINAPI *)(DWORD, DWORD)) GetProcAddress(hLib, "CreateToolhelp32Snapshot");
      Process32FirstPtr=(BOOL(WINAPI *)(HANDLE, LPPROCESSENTRY32)) GetProcAddress(hLib, "Process32First");
      Process32NextPtr=(BOOL(WINAPI *)(HANDLE, LPPROCESSENTRY32)) GetProcAddress(hLib, "Process32Next");

      if (CreateToolhelp32SnapshotPtr && Process32NextPtr && Process32FirstPtr)
      {
        // Get a handle to a Toolhelp snapshot of all the systems processes.
        if ((hSnapShot=(*CreateToolhelp32SnapshotPtr)(TH32CS_SNAPPROCESS, 0)) != INVALID_HANDLE_VALUE)
        {
          // Get the first process' information.
          pe.dwSize=sizeof(PROCESSENTRY32);
          bResult=(*Process32FirstPtr)(hSnapShot, &pe);

          // While there are processes, keep looping and checking.
          while (bResult)
          {
            //Get file name
            for (pName=pe.szExeFile + xstrlenA(pe.szExeFile) - 1; *pName != '\\' && *pName != '\0'; --pName);

            if (!xstrcmpiA(++pName, (const char *)pProcessName))
            {
              // Process found
              bFound=TRUE;

              if (bTerminate == TRUE)
              {
                NiceTerminate(pe.th32ProcessID, dwCloseTimeout, &nSuccess, &nFailed);
              }
              else break;
            }
            //Keep looking
            bResult=(*Process32NextPtr)(hSnapShot, &pe);
          }
          CloseHandle(hSnapShot);
        }
        else uError=611;
      }
      else uError=610;

      FreeLibrary(hLib);
    }
    else uError=609;
  }

  if (bFound == FALSE) return 603;
  if (bTerminate == TRUE)
  {
    if (!nSuccess) return 601;
    if (nFailed) return 602;
  }
  return 0;
}

void NiceTerminate(DWORD pid, DWORD dwCloseTimeout, int *lpnSuccess, int *lpnFailed)
{
  HANDLE hProc;
  UINT_PTR data[2];
  DWORD dwExitCode;
  BOOL bClosed=FALSE;

  if (hProc=OpenProcess(PROCESS_TERMINATE|(dwCloseTimeout ? PROCESS_QUERY_INFORMATION|SYNCHRONIZE : 0), FALSE, pid))
  {
    data[0]=pid;
    data[1]=0;

    if (dwCloseTimeout)
      EnumWindows(EnumWindowsProc, (LPARAM)data);
    if (data[1] != 0)
    {
      if (GetExitCodeProcess(hProc, &dwExitCode) && dwExitCode == STILL_ACTIVE)
      {
        if (WaitForSingleObject(hProc, dwCloseTimeout) == WAIT_OBJECT_0)
        {
          bClosed=TRUE;
          ++*lpnSuccess;
        }
      }
      else
      {
        bClosed=TRUE;
        ++*lpnSuccess;
      }
    }
    if (!bClosed)
    {
      // Open for termination
      if (TerminateProcess(hProc, 0))
        ++*lpnSuccess;
      else
        ++*lpnFailed;
    }
    CloseHandle(hProc);
  }
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
  UINT_PTR *data=(UINT_PTR *)lParam;
  DWORD pid;

  GetWindowThreadProcessId(hwnd, &pid);
  if (pid == data[0])
  {
    PostMessage(hwnd, WM_CLOSE, 0, 0);
    data[1]=(UINT_PTR)hwnd;
  }
  return TRUE;
}

INT_PTR popintegerWide()
{
  wchar_t wszInt[32];

  wszInt[0]=L'\0';
  popstringWide(wszInt, 31);
  return xatoiW(wszInt, NULL);
}

void pushintegerWide(INT_PTR integer)
{
  wchar_t wszInt[32];

  xitoaW(integer, wszInt);
  pushstringWide(wszInt);
}

int popstringAnsi(char *str, int len)
{
  stack_t *th;

  if (g_stacktop && *g_stacktop)
  {
    th=(*g_stacktop);
    if (g_unicode)
    {
      if (len=WideCharToMultiByte(CP_ACP, 0, (const wchar_t *)th->text, -1, str, len, NULL, NULL))
        str[--len]='\0';
    }
    else
    {
      len=(int)xstrcpynA(str, (const char *)th->text, len);
    }
    *g_stacktop=th->next;
    GlobalFree((HGLOBAL)th);
    return len;
  }
  return -1;
}

int popstringWide(wchar_t *str, int len)
{
  stack_t *th;

  if (g_stacktop && *g_stacktop)
  {
    th=(*g_stacktop);
    if (g_unicode)
    {
      len=(int)xstrcpynW(str, th->text, len);
    }
    else
    {
      if (len=MultiByteToWideChar(CP_ACP, 0, (const char *)th->text, -1, str, len))
        str[--len]=L'\0';
    }
    *g_stacktop=th->next;
    GlobalFree((HGLOBAL)th);
    return len;
  }
  return -1;
}

void pushstringAnsi(const char *str)
{
  stack_t *th;

  if (g_stacktop)
  {
    if (g_unicode)
    {
      th=(stack_t *)GlobalAlloc(GPTR, sizeof(stack_t) + NSIS_MAX_STRLEN * sizeof(wchar_t));
      MultiByteToWideChar(CP_ACP, 0, str, -1, (wchar_t *)th->text, NSIS_MAX_STRLEN);
    }
    else
    {
      th=(stack_t *)GlobalAlloc(GPTR, sizeof(stack_t) + NSIS_MAX_STRLEN);
      xstrcpynA((char *)th->text, str, NSIS_MAX_STRLEN);
    }
    th->next=*g_stacktop;
    *g_stacktop=th;
  }
}

void pushstringWide(const wchar_t *str)
{
  stack_t *th;

  if (g_stacktop)
  {
    if (g_unicode)
    {
      th=(stack_t *)GlobalAlloc(GPTR, sizeof(stack_t) + NSIS_MAX_STRLEN * sizeof(wchar_t));
      xstrcpynW(th->text, str, NSIS_MAX_STRLEN);
    }
    else
    {
      th=(stack_t *)GlobalAlloc(GPTR, sizeof(stack_t) + NSIS_MAX_STRLEN);
      WideCharToMultiByte(CP_ACP, 0, str, -1, (char *)th->text, NSIS_MAX_STRLEN, NULL, NULL);
    }
    th->next=*g_stacktop;
    *g_stacktop=th;
  }
}

void Initialize(int string_size, wchar_t *variables, stack_t **stacktop, extra_parameters *extra)
{
  g_stacktop=stacktop;
  g_variables=variables;
  g_stringsize=string_size;
  g_pluginParms=extra;

  if (g_unicode == -1)
  {
    wchar_t wszPath[]=L"C:\\";

    g_pluginParms->validate_filename(wszPath);
    g_unicode=(wszPath[2] == L'\\')?FALSE:TRUE;

    //Initialize WideFunc.h header
    //WideInitialize();
    //WideGlobal_bOldWindows=!g_unicode;
  }
}
